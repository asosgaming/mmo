﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Threading;
using System.Xml;
using System.Security.Cryptography;
using SevenZip;
using Ini;

namespace GameUploader
{
    class Program
    {
        public static string originalFilesDirectory = "";
        public static string compressedFilesDirectory = "zipped";
        public static string uploadFilesDirectory = "upload";
        public static string xmlFileDirectory = "xml";

        public static List<string> allFiles = new List<string>();
        public static List<string> filesToCompress = new List<string>();
        public static List<string> outputFiles = new List<string>();
        public static FtpManager ftp;
        public static string ftpIP;
        public static string ftpLogin;
        public static string ftpPassword;
        public static string ftpPath;
        public static int tasks = 0;

        public static int bigCompressionLine; // the line number (in the console) that will display the progress report for the big compression

        public static ConsoleMessenger ConsoleOutput;

        public static int progress = 0;

        static void Main(string[] args)
        {
            // Hooks up 7zip dll depending on bitness.
            Initialize7zipDll();

            // Reads values from INI and if INI can't be found, prints the exception and exits the program.
            ReadValuesFromIni();

            // Creates the FtpManager.
            InitializeFtpConnection();

            // Initializes ConsoleMessager
            ConsoleOutput = new ConsoleMessenger();

            // Detects all files and prints the number of files detected.
            DetectAllFiles();

            // Creates an XML file for all files in the game directory. The XML contains filename, path, and an MD5 hash.
            CreateXml();

            // Downloads haches from the server. Prints exceptions & quits if couldn't download the hash.
            bool didWeDownloadHashes = DownloadOldXml();

            // If we received no hashes, it means we're uploading the game for the first time and must send ALL game files
            if (didWeDownloadHashes == false)
            {
                foreach (var file in allFiles)
                {
                    // Creates two lists. There's a list of files to compress and the list of files that we'll output after compression (the small archives).
                    AddToCompressionList(file);
                }
            }
            else
            {
                // Detect files that we need to compress and upload by comparing the old hashes with new ones.
                // Old hashes are in oldHash.xml
                // New hashes are in newHashes.xml
                // Creates two lists. There's a list of files to compress and the list of files that we'll output after compression (the small archives).
                // Prints the results after completing the task.
                ManageXmlFiles();
            }

            if (filesToCompress.Count > 0)
            {
                // Compresses all files into separate archives. One archive per file.
                PerformCompression();

                // Packs all archives into one file that we'll upload
                PerformSecondCompression();

                // Uploads the big archive only.
                UploadBigArchive();
            }

            // upload XMLs only if there are actual tasks to do or files to upload
            if (filesToCompress.Count > 0 || tasks > 0)
                UploadNewXml();

            CleanUpFolders();

            ConsoleOutput.AddMessage("All operations complete. Hit any key to exit...");
            Console.ReadKey();
        }

        static void ReadValuesFromIni()
        {
            if (!File.Exists(Path.Combine(Environment.CurrentDirectory, "Settings.ini")))
            {
                PrintException("Settings.ini was not found.");
                PrematureExit("\n"
                + "This error could happen for one of the following reasons: \n"
                + "1) You're recompiling the project and forgot to put the Settings.ini into the correct folder. \n"
                + "2) You deleted the file. \n"
                + "\n"
                + "Restart the program and try again.");
            }
            IniFile ini = new IniFile(Path.Combine(Environment.CurrentDirectory, "Settings.ini"));
            originalFilesDirectory = ini.IniReadValue("", "GameDirectory");
            string tempfolder = ini.IniReadValue("", "TempFolder");
            compressedFilesDirectory = Path.Combine(tempfolder, "zipped");
            uploadFilesDirectory = Path.Combine(tempfolder, "upload");
            xmlFileDirectory = Path.Combine(tempfolder, "xml");
            ftpIP = ini.IniReadValue("", "FtpAddress");
            ftpLogin = ini.IniReadValue("", "FtpLogin");
            ftpPassword = ini.IniReadValue("", "FtpPassword");
            ftpPath = ini.IniReadValue("", "FtpPath");
        }

        static void CleanUpFolders()
        {
            DeleteDirectory(xmlFileDirectory);
            DeleteDirectory(compressedFilesDirectory);
            DeleteDirectory(uploadFilesDirectory);
        }

        static void ManageXmlFiles()
        {
            XmlDocument oldXml = new XmlDocument();
            oldXml.Load(Path.Combine(xmlFileDirectory, "oldHash.xml"));

            XmlDocument newXml = new XmlDocument();
            newXml.Load(Path.Combine(xmlFileDirectory, "newHashes.xml"));

            List<XmlNode> oldHashes = oldXml.SelectNodes("//File").Cast<XmlNode>().ToList();
            List<XmlNode> newHashes = newXml.SelectNodes("//File").Cast<XmlNode>().ToList();

            List<XmlNode> noDeleteList = new List<XmlNode>();

            // Because keys must be unique in a dictionary, we'll have to use counter-intuietively the second string as the source file and the first one as the target file.
            Dictionary<string, string> copyFiles = new Dictionary<string, string>();
            // Not the case here, so the first string is original name, and the second is the name after renaming.
            Dictionary<string, string> renameFiles = new Dictionary<string, string>();

            int noChanges = 0;
            int renamedMovedFiles = 0;
            int copiedFiles = 0;

            foreach (XmlNode newNode in newHashes)
            {
                // We skip files that we already treated in a certain rare case (the big explanation with a screenshot 50 lines below)
                if (copyFiles.ContainsKey(newNode.GetPath()))
                {
                    continue;
                }

                // finds a node with the same path
                XmlNode oldNode = oldHashes.FirstOrDefault(x => x.GetPath() == newNode.GetPath());

                // if found
                if (oldNode != null)
                {
                    // if the file has the same size and hash
                    if (oldNode.GetSize() == newNode.GetSize() && oldNode.GetHash() == newNode.GetHash())
                    {
                        // it's the same file. nothing has to be done.
                        noDeleteList.Add(oldNode);
                        noChanges++;
                    }
                    // if the size or hash changed, the file needs to be reuploaded
                    else
                    {
                        noDeleteList.Add(oldNode);
                        // add to list of files to compress and upload
                        AddToCompressionList(Path.Combine(originalFilesDirectory,newNode.GetPath()));
                    }
                }
                // if not found at the same path
                else
                {
                    // see if it wasn't simply renamed or moved
                    oldNode = oldHashes.FirstOrDefault(x => x.GetSize() == newNode.GetSize() && x.GetHash() == newNode.GetHash());

                    // if it was renamed/moved/copied
                    if (oldNode != null)
                    {
                        // if it's a copy (if we're keeping the oldNode at the same path)
                        if (newHashes.FirstOrDefault(x => x.GetPath() == oldNode.GetPath() && x != newNode) != null)
                        {
                            // add to list of files to copy from oldNode path to newNode path
                            noDeleteList.Add(oldNode);

                            // copy from oldNode.GetPath() to newHashes.GetPath()
                            // we reverse the parameters because the keys must be unique in a dictionary
                            copyFiles.Add(newNode.GetPath(), oldNode.GetPath());

                            copiedFiles++;
                        }
                        // if it's a move/rename
                        else
                        {
                            // Now we'd simply move/rename it, but what if there are other copies of this file that would like to use
                            // the original file as a base for their move/rename?
                            // An example of this kind of situation: https://i.gyazo.com/eaef516a0feb71d90ea8cbb72bd4f91f.png
                            // In this case, we need to move/rename the first one, and copy others from the newly moved/renamed one.
                            // And then we need to skip treatment of the ones we marked for copying.

                            // Let's find all files just like this one in the list of files to upload.
                            // If there's only one (this one), we just move/rename it and nothing else is required.
                            renameFiles.Add(oldNode.GetPath(), newNode.GetPath());
                            noDeleteList.Add(oldNode);
                            renamedMovedFiles++;

                            // if there are others, let's find them all and mark them all to be copied from the newly renamed file
                            if (newHashes.FirstOrDefault(x => x.GetSize() == newNode.GetSize() && x.GetHash() == newNode.GetHash() && x != newNode) != null)
                            {
                                List<XmlNode> allCopies = newHashes.FindAll(x => x.GetSize() == newNode.GetSize() && x.GetHash() == newNode.GetHash() && x != newNode);
                                foreach(XmlNode copy in allCopies)
                                {
                                    copiedFiles++;
                                    // we reverse the parameters because the keys must be unique in a dictionary
                                    copyFiles.Add(copy.GetPath(), newNode.GetPath());
                                }
                            }
                        }
                    }
                    // if it simply didn't exist before on the server
                    else
                    {
                        // add to list of files to compress and upload
                        AddToCompressionList(Path.Combine(originalFilesDirectory, newNode.GetPath()));
                    }
                }
            }

            List<XmlNode> deleteFiles = oldHashes.Except(noDeleteList).ToList();

            ConsoleOutput.AddMessage("No changes: " + noChanges);
            ConsoleOutput.AddMessage("Upload files: " + filesToCompress.Count);
            ConsoleOutput.AddMessage("Renamed/moved files: " + renamedMovedFiles);
            ConsoleOutput.AddMessage("Copied files: " + copiedFiles);
            ConsoleOutput.AddMessage("Delete files: " + deleteFiles.Count);

            GenerateAdditionalTasks(deleteFiles, renameFiles, copyFiles);

            ConsoleOutput.AddMessage("");
        }

        // Generates an xml file for the server to read and perform additional tasks of deleting, renaming/moving and copying files.
        static void GenerateAdditionalTasks(List<XmlNode> deleteFiles, Dictionary<string, string> renameFiles, Dictionary<string, string> copyFiles)
        {
            using (XmlWriter writer = XmlWriter.Create(Path.Combine(xmlFileDirectory, "tasks.xml")))
            {
                writer.WriteStartDocument();
                writer.WriteStartElement("Files");

                foreach (XmlNode file in deleteFiles)
                {
                    tasks++;
                    writer.WriteStartElement("Delete");
                    writer.WriteElementString("Path", file.GetPath());
                    writer.WriteEndElement();
                }

                foreach (KeyValuePair<string, string> file in renameFiles)
                {
                    tasks++;
                    writer.WriteStartElement("Rename");
                    writer.WriteElementString("From", file.Key);
                    writer.WriteElementString("To", file.Value);
                    writer.WriteEndElement();
                }

                foreach (var file in copyFiles)
                {
                    tasks++;
                    writer.WriteStartElement("Copy");
                    writer.WriteElementString("From", file.Value);
                    writer.WriteElementString("To", file.Key);
                    writer.WriteEndElement();
                }

                writer.WriteEndElement();
                writer.WriteEndDocument();
            }
        }

        static void AddToCompressionList(string file)
        {
            filesToCompress.Add(file);

            // a second list of output files is being composed here as well
            outputFiles.Add(file.Replace(originalFilesDirectory, compressedFilesDirectory));
        }

        static void UploadNewXml()
        {
            ftp.createDirectory("newupdate");
            ftp.upload(ftpPath+"newupdate/hash.xml", Path.Combine(xmlFileDirectory, "newHashes.xml"));
            if (File.Exists(Path.Combine(xmlFileDirectory, "tasks.xml")))
                ftp.upload(ftpPath+"newupdate/tasks.xml", Path.Combine(xmlFileDirectory, "tasks.xml"));
        }

        // Uploads the big archive that contains all the smaller archives
        static void UploadBigArchive()
        {
            ftp.createDirectory(ftpPath+"newupdate");

            // printing time
            DateTime timeStart = DateTime.Now;
            ConsoleOutput.AddMessage(timeStart.ToString("HH:mm:ss") + " Uploading files.");

            // a separate thread for progress reporting is started
            Thread progThread = new Thread(new ParameterizedThreadStart(DisplayProgress));
            progThread.Start(100);
            progress = 0;

            // upload the big archive
            ftp.upload(ftpPath+"newupdate/UpdateToUpload.zip", Path.Combine(uploadFilesDirectory, "UpdateToUpload.zip"));
            progress = -1;

            DateTime timeEnd = DateTime.Now;
            ConsoleOutput.AddMessage(timeEnd.ToString("HH:mm:ss") + " Upload finished.");
            ConsoleOutput.AddMessage("");
        }

        // Loads the correct 7z.dll depending on the program's "bitness".
        // No real speed difference between 32 and 64 versions has been observed, so it's just a formality at this point.
        static void Initialize7zipDll()
        {
            if (Environment.Is64BitProcess)
            {
                //Console.WriteLine("The program is running under 64 bits.");
                SevenZip.SevenZipExtractor.SetLibraryPath(Path.Combine(Environment.CurrentDirectory, "7z64.dll"));
            }
            else
            {
                //Console.WriteLine("The program is running under 32 bits.");
                SevenZip.SevenZipExtractor.SetLibraryPath(Path.Combine(Environment.CurrentDirectory, "7z.dll"));
            }
        }

        static void PrematureExit(string reason = "")
        {
            if (reason == "")
            {
                ConsoleOutput.AddMessage("Some operations didn't go through. Restart the application when you've fixed the reason for the error.");
            }
            else
            {
                ConsoleOutput.AddMessage(reason);
            }
            ConsoleOutput.AddMessage("Hit any key to close program...");
            Console.ReadKey();
            Environment.Exit(-1);
        }

        static void DetectAllFiles()
        {
            // go through all files and add them to the list of files to compress
            foreach (string file in Directory.EnumerateFiles(originalFilesDirectory, "*", SearchOption.AllDirectories))
            {
                allFiles.Add(file);
            }
            ConsoleOutput.AddMessage("Detected " + allFiles.Count + " files.");
            ConsoleOutput.AddMessage("");
        }

        static bool DownloadOldXml()
        {
            if (File.Exists(Path.Combine(xmlFileDirectory, "oldHash.xml")))
                File.Delete(Path.Combine(xmlFileDirectory, "oldHash.xml"));

            ConsoleOutput.AddMessage("Downloading: " + ftpPath + "hash.xml");
            int code = ftp.download(ftpPath+"hash.xml", Path.Combine(xmlFileDirectory, "oldHash.xml"));
            //ConsoleOutput.AddMessage("Code: " + code);
            if (code == 550)
            {
                // If Code 550 was returned, it means hash.xml wasn't found on the server, and this means we're uploading our game for the first time.
                ConsoleOutput.AddMessage("Hash.xml was not present on the server.");
                ConsoleOutput.AddMessage("It means you're uploading a game version for the first time.");
                ConsoleOutput.AddMessage("");
            }
            else if (code == -1)
            {
                // Means the server is down or we have no internet connection? Either way, we exit.
                PrematureExit("\n"
                + "This error could happen for one of the following reasons: \n"
                +"1) The FTP server is down. \n"
                +"2) Your internet connection is down. \n"
                +"3) You typed in the wrong IP address. \n"
                +"4) You set something up incorrectly on the FTP or in the Settings (FtpPath or FtpAddress for example). \n"
                +"\n"
                +"Restart the program and try again.");
            }
            else if (code == 530)
            {
                PrematureExit("This error is caused by incorrect login/password. \n"
                + "Restart the program and try again.");
            }
            else if (code == 1)
            {
                // Means we downloaded the file successfully.
                ConsoleOutput.AddMessage("Hash.xml was downloaded successfully.");
                ConsoleOutput.AddMessage("");
                return true;
            }

            return false;
        }

        static void InitializeFtpConnection()
        {
            ftp = new FtpManager(ftpIP, ftpLogin, ftpPassword);
        }

        static void CreateXml()
        {
            if (!Directory.Exists(xmlFileDirectory))
            {
                Directory.CreateDirectory(xmlFileDirectory);
            }

            using (XmlWriter writer = XmlWriter.Create(Path.Combine(xmlFileDirectory, "newHashes.xml")))
            {
                writer.WriteStartDocument();
                writer.WriteStartElement("Files");

                // printing time
                DateTime timeStart = DateTime.Now;
                ConsoleOutput.AddMessage(timeStart.ToString("HH:mm:ss") + " Generating hashes.");

                // a separate thread for progress reporting is started
                Thread progThread = new Thread(new ParameterizedThreadStart(DisplayProgress));
                progThread.Start(allFiles.Count);
                progress = 0;

                foreach (string file in allFiles)
                {
                    writer.WriteStartElement("File");

                    writer.WriteElementString("Path", file.Replace(originalFilesDirectory+Path.DirectorySeparatorChar, ""));

                    FileInfo fInfo = new FileInfo(file);
                    writer.WriteElementString("Size", fInfo.Length.ToString());

                    SHA256 mySHA256 = SHA256Managed.Create();
                    byte[] hashValue;

                    // Create a fileStream for the file.
                    FileStream fileStream = fInfo.Open(FileMode.Open);
                    // Be sure it's positioned to the beginning of the stream.
                    fileStream.Position = 0;
                    // Compute the hash of the fileStream.
                    hashValue = mySHA256.ComputeHash(fileStream);
                    // Close the file.
                    fileStream.Close();

                    writer.WriteElementString("Hash", Convert.ToBase64String(hashValue));

                    writer.WriteEndElement();

                    progress++;
                }
                progress = -1;

                writer.WriteEndElement();
                writer.WriteEndDocument();

                DateTime timeEnd = DateTime.Now;
                ConsoleOutput.AddMessage(timeEnd.ToString("HH:mm:ss") + " Hash generation complete.");
                ConsoleOutput.AddMessage("");
            }
        }

        // For each file in your game directory, this method will create a separate archive (7z) in a temporary neighbor directory.
        static void PerformCompression()
        {
            // compress into separate small archives

            // empty the folder where we put all the archives
            if (Directory.Exists(compressedFilesDirectory))
            {
                DeleteDirectory(compressedFilesDirectory);
            }
            Directory.CreateDirectory(compressedFilesDirectory);

            // configuring the SevenZipCompressor
            var compressor1 = new SevenZip.SevenZipCompressor();
            compressor1.ScanOnlyWritable = true;
            compressor1.CompressionLevel = SevenZip.CompressionLevel.Fast;
            compressor1.ArchiveFormat = SevenZip.OutArchiveFormat.Zip;
            compressor1.CompressionMethod = SevenZip.CompressionMethod.Deflate;
            compressor1.TempFolderPath = compressedFilesDirectory;

            // printing time
            DateTime timeStart = DateTime.Now;
            ConsoleOutput.AddMessage(timeStart.ToString("HH:mm:ss") + " Beginning separate compression.");

            // TODO: also find empty directories and zip them through CompressDirectory, otherwise they get lost. May potentially cause problems for some engines.
            // Upd: it would actually really be annoying for the rest of the updating algorithm. Don't do that.

            ConsoleOutput.AddMessage("Found " + filesToCompress.Count + " files to zip.");

            // a separate thread for progress reporting is started
            Thread progThread = new Thread(new ParameterizedThreadStart(DisplayProgress));
            progThread.Start(filesToCompress.Count);

            // archiving all files
            for (progress = 0; progress < filesToCompress.Count; progress++)
            {
                if (!Directory.Exists(Path.GetDirectoryName(outputFiles[progress])))
                {
                    Directory.CreateDirectory(Path.GetDirectoryName(outputFiles[progress]));
                }
                compressor1.CompressFiles(outputFiles[progress] + ".7z", filesToCompress[progress]);
            }

            // stops the progress reports
            progress = -1; //progThread.Abort();

            DateTime timeEnd = DateTime.Now;
            ConsoleOutput.AddMessage(timeEnd.ToString("HH:mm:ss") + " Finished.");

            TimeSpan result = timeEnd - timeStart;
            ConsoleOutput.AddMessage(String.Format("Took {0} seconds. ({1} minutes, {2} seconds)", (int)result.TotalSeconds, result.Minutes, result.Seconds));
            ConsoleOutput.AddMessage("");
        }
        
        static void PerformSecondCompression()
        {
            if (Directory.Exists(uploadFilesDirectory))
                DeleteDirectory(uploadFilesDirectory);
            Directory.CreateDirectory(uploadFilesDirectory);

            // printing time
            DateTime timeStart = DateTime.Now;
            ConsoleOutput.AddMessage(timeStart.ToString("HH:mm:ss") + " Beginning big compression.");

            // configuring the SevenZipCompressor
            var compressor1 = new SevenZipCompressor();
            compressor1.ScanOnlyWritable = true;
            compressor1.CompressionLevel = CompressionLevel.None;
            compressor1.ArchiveFormat = OutArchiveFormat.Zip;
            compressor1.CompressionMethod = CompressionMethod.Deflate; // php can only unzip Deflate and Bzip2 TODO: test speed of both those formats
            compressor1.TempFolderPath = uploadFilesDirectory;

            bigCompressionLine = ConsoleOutput.AddMessage("Progress: 0%");
            // registers events for percentage reporting
            compressor1.Compressing += new EventHandler<ProgressEventArgs>(cmp_Compressing);
            compressor1.CompressionFinished += new EventHandler<EventArgs>(cmp_CompressionFinished);

            compressor1.CompressDirectory(compressedFilesDirectory, Path.Combine(uploadFilesDirectory, "UpdateToUpload.zip"));

            DateTime timeEnd = DateTime.Now;
            ConsoleOutput.AddMessage(timeEnd.ToString("HH:mm:ss") + " Finished.");

            TimeSpan result = timeEnd - timeStart;
            ConsoleOutput.AddMessage(String.Format("Took {0} seconds. ({1} minutes, {2} seconds)", (int)result.TotalSeconds, result.Minutes, result.Seconds));
            ConsoleOutput.AddMessage("");
        }

        static void cmp_Compressing(object sender, ProgressEventArgs e)
        {
            ConsoleOutput.EditMessage(bigCompressionLine, "Progress: " + e.PercentDone + "%");
        }

        static void cmp_CompressionFinished(object sender, EventArgs e)
        {
            ConsoleOutput.EditMessage(bigCompressionLine, "Progress: 100%");
        }


        // The parameter is an int. It's the number of total files to archive.
        static void DisplayProgress(object info)
        {
            int maxInt = (int)info;
            int lineNumber = ConsoleOutput.AddMessage("koko");
            float percentage;

            // this loop is stopped from the main thread by setting progress to -1
            while (progress != -1)
            {
                percentage = ((float)progress) / (float)maxInt * 100;
                ConsoleOutput.EditMessage(lineNumber, "Progress: " + progress + "/" + maxInt + " (" + percentage.ToString("0.00") + "%)");
                System.Threading.Thread.Sleep(250);
            }

            ConsoleOutput.EditMessage(lineNumber, "Progress: " + maxInt + "/" + maxInt + " (100%)");
        }

        public static void PrintException(string text)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            ConsoleOutput.AddMessage(text, ConsoleColor.Red);
        }

        public static void DeleteDirectory(string target_dir)
        {
            if (Directory.Exists(target_dir))
            {
                string[] files = Directory.GetFiles(target_dir);
                string[] dirs = Directory.GetDirectories(target_dir);

                foreach (string file in files)
                {
                    File.SetAttributes(file, FileAttributes.Normal);
                    File.Delete(file);
                }

                foreach (string dir in dirs)
                {
                    DeleteDirectory(dir);
                }

                Directory.Delete(target_dir, false);
            }
        }
    }

    public static class ExtensionMethods
    {
        public static string GetPath(this XmlNode node)
        {
            return node.ChildNodes[0].InnerText;
        }

        public static string GetSize(this XmlNode node)
        {
            return node.ChildNodes[1].InnerText;
        }

        public static string GetHash(this XmlNode node)
        {
            return node.ChildNodes[2].InnerText;
        }
    }
}


//if (decompressSmallFiles)
//{
//    DateTime timeStart = DateTime.Now;
//    Console.WriteLine(timeStart.ToString("HH:mm:ss") + " Beginning separate archives extraction.");

//    List<string> archivesToExtract = new List<string>();
//    List<string> outputFiles = new List<string>();

//    foreach (string file in Directory.EnumerateFiles(encodedIndividual, "*.*", SearchOption.AllDirectories))
//    {
//        archivesToExtract.Add(file);
//        outputFiles.Add(file.Replace("encoded-v2", "decoded-v2"));
//    }
//    Console.WriteLine("Found " + archivesToExtract.Count + " zip files.");

//    for (int i = 0; i < archivesToExtract.Count; i++)
//    {
//        if (!Directory.Exists(Path.GetDirectoryName(outputFiles[i])))
//        {
//            Directory.CreateDirectory(Path.GetDirectoryName(outputFiles[i]));
//        }

//        var decompressor1 = new SevenZip.SevenZipExtractor(archivesToExtract[i]);
//        decompressor1.ExtractArchive(Path.GetDirectoryName(outputFiles[i]));
//    }

//    DateTime timeEnd = DateTime.Now;
//    Console.WriteLine(timeEnd.ToString("HH:mm:ss") + " Finished.");

//    TimeSpan result = timeEnd - timeStart;
//    Console.WriteLine(String.Format("Took {0} seconds. ({1} minutes, {2} seconds)", (int)result.TotalSeconds, result.Minutes, result.Seconds));    
//}