﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Xml;
using System.Security.Cryptography;
using System.Net;
using SharpCompress.Common;
using SharpCompress.Archive;
using Ini;

namespace Launcher01
{
    static class Program
    {
        public static XmlDocument localXml;
        public static XmlDocument serverXml;
        public static XmlDocument zipSizeXml; //used for progress bar only
        public static List<XmlNode> filesToDownload = new List<XmlNode>();
        static string currentDirectory;
        static string tempDirectory;
        public static List<string> allFiles = new List<string>();
        public static string httpAdr; // example "http://rien-ici.com/launcher/" - must use a trailing slash
        public static string exePath;

        public static int totalFilesToDownload = 0;
        public static int totalFilesDownloaded = 0;

        public static double totalBytesToDownload;
        public static double totalBytesDownloaded;

        public static Form1 MainForm;

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            currentDirectory = Environment.CurrentDirectory;
            tempDirectory = Path.Combine(currentDirectory, "update_tmp");

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            MainForm = new Form1();
            Application.Run(MainForm);
        }

        public static async Task GetServerXml()
        {
            if (File.Exists(Path.Combine(currentDirectory, "serverHash.xml")))
                File.Delete(Path.Combine(currentDirectory, "serverHash.xml"));

            if (File.Exists(Path.Combine(currentDirectory, "ZipSize.xml")))
                File.Delete(Path.Combine(currentDirectory, "ZipSize.xml"));

            await Task.Run(() => httpDownloadFile(httpAdr + "hash.xml", Path.Combine(currentDirectory, "serverHash.xml")));
            await Task.Run(() => httpDownloadFile(httpAdr + "ZipSize.xml", Path.Combine(currentDirectory, "ZipSize.xml")));

            serverXml = new XmlDocument();
            serverXml.Load(Path.Combine(currentDirectory, "serverHash.xml"));

            zipSizeXml = new XmlDocument();
            zipSizeXml.Load(Path.Combine(currentDirectory, "ZipSize.xml"));
        }
            

        public static bool ReadValuesFromIni()
        {
            if (!File.Exists(Path.Combine(Environment.CurrentDirectory, "LauncherSettings.ini")))
            {
                // an error will be displayed in Form1.cs
                return false;
            }
            IniFile ini = new IniFile(Path.Combine(Environment.CurrentDirectory, "LauncherSettings.ini"));
            httpAdr = ini.IniReadValue("", "HttpAddress");
            exePath = ini.IniReadValue("", "ExePath");
            exePath = Path.Combine(Environment.CurrentDirectory, exePath);

            if (httpAdr.Length == 0)
            {
                return false;
            }

            // adds a trailing slash for those who'd forget it in the ini file
            if (httpAdr[httpAdr.Length - 1] != '/')
            {
                httpAdr += '/';
            }

            return true;
        }

        public static void httpDownloadFile(string url, string Dest, string filesize = "0")
        {
            Dest = Dest.Replace('\\', Path.DirectorySeparatorChar);
            //Console.WriteLine("Downloading url: " + url);
            //Console.WriteLine("Destination path: " + Dest);
          
            
            int retries = 0;

            if (!Directory.Exists(Path.GetDirectoryName(Dest)))
                Directory.CreateDirectory(Path.GetDirectoryName(Dest));

        retry:
            try
            {
                const int BUFFER_SIZE = 16 * 1024;
                using (var outputFileStream = File.Create(Dest, BUFFER_SIZE))
                {
                    var req = WebRequest.Create(url);
                    using (var response = req.GetResponse())
                    {
                        using (var responseStream = response.GetResponseStream())
                        {
                            var buffer = new byte[BUFFER_SIZE];
                            int bytesRead;
                            do
                            {
                                bytesRead = responseStream.Read(buffer, 0, BUFFER_SIZE);
                                outputFileStream.Write(buffer, 0, bytesRead);

                                totalBytesDownloaded += bytesRead;
                                
                                if (totalBytesToDownload != 0)
                                {
                                    if (totalBytesDownloaded > totalBytesToDownload) totalBytesDownloaded = totalBytesToDownload;
                                    
                                    float progress = 100 * (float)totalBytesDownloaded / (float)totalBytesToDownload;
                                    progress *= 0.8f; // we assume that downloading takes 80% of the time and decompression 20%
                                    MainForm.SetProgress((int)progress);
                                    MainForm.SetStatus(String.Format("Downloading: {0}MB", ((totalBytesToDownload - totalBytesDownloaded) / 1048576).ToString("0.##"))); // bytes to megabytes

                                }
                               

                            } while (bytesRead > 0);
                        }
                    }
                }
                

            }

            catch (Exception ee)
            {
                if (!ee.Message.Contains("404") && !ee.Message.Contains("403")) //!= "The remote server returned an error: (404) Not Found." && ee.Message != "The remote server returned an error: (403) Forbidden.")
                {
                    //if (ee.Message.StartsWith("The operation has timed out") || ee.Message == "Unable to connect to the remote server" || ee.Message.StartsWith("The request was aborted: ") || ee.Message.StartsWith("Unable to read data from the trans­port con­nec­tion: ") || ee.Message == "The remote server returned an error: (408) Request Timeout.")
                        retries++;
                    //else
                        //MessageBox.Show(ee.Message, "Error at line 155 in Program.cs", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    goto retry; // can replace it with httpDownloadFile(url, Dest);
                }
                // TODO: else, we're trying to download an inexisting file. This can happen if a user tries to update while the repository is getting updated by the master.
            }

            if (!url.EndsWith("hash.xml") && !url.EndsWith("ZipSize.xml"))
            {
                totalFilesDownloaded++;
               
                MainForm.SetStatus2("Remaining files: " + (totalFilesToDownload - totalFilesDownloaded).ToString("#,##0")); //You get: 1,000,000,000       
          

               // float progress = (100 * totalFilesDownloaded) / totalFilesToDownload;
               
            }
        }

        /* If there is an XML, just load it into memory. 
         * If it's not there, generate it. It could be missing for one of the following reasons:
         * a) The game is currently being installed for the first time.
         * b) The user erased the XML file accidentally.
         * c) The game needs to be repaired, so the old xml file is useless and we therefore erased it.
         */
        public static void loadLocalXml()
        {
            if (!File.Exists(Path.Combine(currentDirectory, "localHash.xml")))
            {
                CreateXml();
            }
            localXml = new XmlDocument();
            localXml.Load(Path.Combine(currentDirectory, "localHash.xml"));
        }

        // Detects all files, except the ones that are part of the Launcher
        static void DetectAllFiles()
        {
            // go through all files and add them to the list of files to compress
            foreach (string file in Directory.EnumerateFiles(currentDirectory, "*", SearchOption.AllDirectories))
            {
                allFiles.Add(file.Replace(currentDirectory + Path.DirectorySeparatorChar, ""));
                Console.WriteLine("Adding: " + file);
            }

            List<string> exclusion = new List<string>
            {
                "LauncherSettings.ini",
                "localHash.xml",
                "serverHash.xml",
                "SharpCompress.dll",
                AppDomain.CurrentDomain.FriendlyName.Replace(".vshost", ""),                //"Launcher01.exe"
                AppDomain.CurrentDomain.FriendlyName,                                       //"Launcher01.vshost.exe"
                AppDomain.CurrentDomain.FriendlyName.Replace(".vshost", "") + ".config",    //"Launcher01.exe.config"
                AppDomain.CurrentDomain.FriendlyName.Replace(".vshost.exe", ".pdb"),        //"Launcher01.pdb"
                AppDomain.CurrentDomain.FriendlyName.Replace(".exe", ".pdb"),               //"Launcher01.pdb"
                AppDomain.CurrentDomain.FriendlyName + ".config",                           //"Launcher01.vshost.exe.config"
                AppDomain.CurrentDomain.FriendlyName + ".manifest"                          //"Launcher01.vshost.exe.manifest"
            };

            allFiles = allFiles.Except(exclusion).ToList();

            Console.WriteLine("Detected " + allFiles.Count + " files.");
        }

        static void CreateXml()
        {
            Console.WriteLine("Generating XML.");

            MainForm.SetStatus("Scanning local files");

            DetectAllFiles();

            using (XmlWriter writer = XmlWriter.Create(Path.Combine(currentDirectory, "localHash.xml")))
            {
                writer.WriteStartDocument();
                writer.WriteStartElement("Files");

                foreach (string file in allFiles)
                {
                    writer.WriteStartElement("File");

                    string filePath = file.Replace(currentDirectory + Path.DirectorySeparatorChar, "");
                    // this needs to be done on linux/macos, because the server-side hashes will be generated with backslashes on Windows
                    filePath = filePath.Replace(Path.DirectorySeparatorChar, '\\');
                    writer.WriteElementString("Path", filePath);

                    FileInfo fInfo = new FileInfo(file);
                    writer.WriteElementString("Size", fInfo.Length.ToString());

                    SHA256 mySHA256 = SHA256Managed.Create();
                    byte[] hashValue;

                    // Create a fileStream for the file.
                    // TODO: if a file is being used (for example, an .exe that is running), then the filestream will fail. Solve this somehow and add a try-catch.
                    FileStream fileStream = fInfo.Open(FileMode.Open);
                    // Be sure it's positioned to the beginning of the stream.
                    fileStream.Position = 0;
                    // Compute the hash of the fileStream.
                    hashValue = mySHA256.ComputeHash(fileStream);
                    // Close the file.
                    fileStream.Close();

                    writer.WriteElementString("Hash", Convert.ToBase64String(hashValue));
                    writer.WriteEndElement();
                }

                writer.WriteEndElement();
                writer.WriteEndDocument();
            }
        }

        public static void CalculateDifferences()
        {
            List<XmlNode> localFiles = localXml.SelectNodes("//File").Cast<XmlNode>().ToList();
            List<XmlNode> serverFiles = serverXml.SelectNodes("//File").Cast<XmlNode>().ToList();
            filesToDownload.Clear();

            foreach (XmlNode serverFile in serverFiles)
            {
                // Find local file with the same name.
                XmlNode matchingFile = localFiles.FirstOrDefault(x => x.GetPath() == serverFile.GetPath());

                /* If a file with the same name was found:
                 * 1) Check if the file has the same hash and size. If so, no action is required.
                 * 2) If the hash/size is different, then the file needs to be updated.
                 * 
                 * If the file with the same name wasn't found locally:
                 * 1) It needs to be downloaded.
                 */
                if (matchingFile != null)
                {
                    if (matchingFile.GetSize() == serverFile.GetSize() && matchingFile.GetHash() == serverFile.GetHash())
                        continue;
                    else
                        filesToDownload.Add(serverFile);
                }
                else
                {
                    filesToDownload.Add(serverFile);
                }
            }

            Console.WriteLine("DIFFERENCES: " + filesToDownload.Count + " files to download.");

            long totalSize = 0;
            foreach (var file in filesToDownload)
            {
                totalSize += long.Parse(file.GetSize());
            }

            // Bytes to MegaBytes
            totalSize /= 1024;
            totalSize /= 1024;

            Console.WriteLine("DIFFERENCES: Downloading " + totalSize + " MB.");
        }

        public static void DownloadRequiredFiles()
        {
            string tempDir = Path.Combine(currentDirectory, "Temp");
            if (!Directory.Exists(tempDir))
            {
                Directory.CreateDirectory(tempDir);
            }

            // TODO: Check available disk space

            totalFilesToDownload = filesToDownload.Count;
            totalFilesDownloaded = 0;

            MainForm.SetStatus2("Remaining files: " + (totalFilesToDownload - totalFilesDownloaded).ToString("#,##0")); //You get: 1,000,000,000

            List<XmlNode> zipFiles = zipSizeXml.SelectNodes("//File").Cast<XmlNode>().ToList();

            totalBytesToDownload = 0;
            foreach(var file in filesToDownload)
            {
                string path = file.GetPath();
                var zipfile = zipFiles.FirstOrDefault(x => x.GetPath().Remove(x.GetPath().Length-3).Replace("/", "\\") == path);
                if (zipfile == null)
                {
                    Console.WriteLine("Problem..."); // place a breakpoint here. Although this should never happen.
                }
                else
                {
                    totalBytesToDownload += double.Parse(zipfile.GetSize());
                }
            }
            // sets it just one time
            MainForm.SetStatus(String.Format("Downloading: {0}MB", (totalBytesToDownload / 1048576).ToString ("0.##"))); // bytes to megabytes

            // will download files in 8 streams in parallel, 1 stream per file. It speeds up the download of many small files.
            filesToDownload.AsParallel().WithDegreeOfParallelism(8).WithExecutionMode(ParallelExecutionMode.ForceParallelism).ForAll(x => httpDownloadFile(httpAdr + "game/" + x.GetPath().Replace('\\', '/') + ".7z", Path.Combine(tempDir, x.GetPath() + ".7z"), x.GetSize()));
        }

        public static void ApplyPatch()
        {
            string tempDir = Path.Combine(currentDirectory, "Temp");
            string extractDir = Path.Combine(currentDirectory, "Game");

            int filesDecompressed = 0;

            MainForm.SetStatus2("");
            MainForm.SetStatus(String.Format("Applying patch: {0} / {1}", filesDecompressed, totalFilesToDownload));

            foreach (var file in filesToDownload)
            {
                string finalDirectory = Path.GetDirectoryName(Path.Combine(extractDir, file.GetPath().Replace('\\', Path.DirectorySeparatorChar)));
                DecompressArchive(Path.Combine(tempDir, file.GetPath().Replace('\\', Path.DirectorySeparatorChar) + ".7z"), finalDirectory);

                filesDecompressed++;
                MainForm.SetStatus(String.Format("Applying patch: {0} / {1}", filesDecompressed, totalFilesToDownload));

                float progress = (100 * filesDecompressed) / totalFilesToDownload;
                progress *= 0.2f; // we assume that downloading takes 80% of the time and decompression 20%
                progress += 80;
                MainForm.SetProgress((int)progress);                
            }
        }

        private static void DecompressArchive(string sourceFile, string destinationPath)
        {
            if (!Directory.Exists(destinationPath))
            {
                Directory.CreateDirectory(destinationPath);
            }

            try
            {
                using (Stream stream = File.OpenRead(sourceFile))
                {
                    using (var archive = SharpCompress.Archive.ArchiveFactory.Open(stream))
                    {
                        archive.Entries.First().WriteToDirectory(destinationPath, ExtractOptions.ExtractFullPath | ExtractOptions.Overwrite);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void FinalizePatch()
        {
            MainForm.SetStatus("Finalizing...");
            File.Delete(Path.Combine(currentDirectory, "localHash.xml"));
            File.Move(Path.Combine(currentDirectory, "serverHash.xml"), Path.Combine(currentDirectory, "localHash.xml"));
            EmptyTempFolder();
        }

        // Empties the Temp directory.
        public static void EmptyTempFolder()
        {
            string tempDir = Path.Combine(currentDirectory, "Temp");
            if (!Directory.Exists(tempDir))
            {
                return;
            }

            DirectoryInfo downloadedMessageInfo = new DirectoryInfo(Path.Combine(currentDirectory, "Temp"));
            foreach (FileInfo file in downloadedMessageInfo.GetFiles("*.*", SearchOption.AllDirectories))
            {
                // Waits till the file gets released. It can sometimes get locked if you close the Launcher during unzipping. It only gets locked for a couple of seconds.
                while (IsFileLocked(file))
                {
                    System.Threading.Thread.Sleep(50);
                }
                file.Delete();
            }
            foreach (DirectoryInfo dir in downloadedMessageInfo.GetDirectories())
            {
                while(!DeleteFolder(dir))
                {
                    System.Threading.Thread.Sleep(50);
                }
            }
        }

        public static bool DeleteFolder(DirectoryInfo dir)
        {
            try
            {
                dir.Delete(true);
                return true;
            }
            catch (IOException)
            {
                // couldn't delete the folder, since it's still locked
                return false;
            }
        }

        static bool IsFileLocked(FileInfo file)
        {
            FileStream stream = null;

            try
            {
                stream = file.Open(FileMode.Open, FileAccess.Read, FileShare.None);
            }
            catch (IOException)
            {
                //the file is unavailable because it is:
                //still being written to
                //or being processed by another thread
                //or does not exist (has already been processed)
                return true;
            }
            finally
            {
                if (stream != null)
                    stream.Close();
            }

            //file is not locked
            return false;
        }
    }



    public static class ExtensionMethods
    {
        public static string GetPath(this XmlNode node)
        {
            return node.ChildNodes[0].InnerText;
        }

        public static string GetSize(this XmlNode node)
        {
            return node.ChildNodes[1].InnerText;
        }

        public static string GetHash(this XmlNode node)
        {
            return node.ChildNodes[2].InnerText;
        }
    }
}
