﻿namespace Launcher01
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.ProgressBarFg = new System.Windows.Forms.PictureBox();
            this.statusLabel2 = new Launcher01.AdvancedLabel();
            this.siteLabel = new Launcher01.AdvancedLabel();
            this.finalLabel = new Launcher01.AdvancedLabel();
            this.progressLabel = new Launcher01.AdvancedLabel();
            this.advancedLabel3 = new Launcher01.AdvancedLabel();
            this.advancedLabel2 = new Launcher01.AdvancedLabel();
            this.closeAdvBtn = new Launcher01.AdvancedButton();
            this.minimizeAdvBtn = new Launcher01.AdvancedButton();
            this.statusLabel = new Launcher01.AdvancedLabel();
            this.PlayButton = new Launcher01.AdvancedButton();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ProgressBarFg)).BeginInit();
            this.SuspendLayout();
            // 
            // backgroundWorker1
            // 
            this.backgroundWorker1.WorkerReportsProgress = true;
            this.backgroundWorker1.WorkerSupportsCancellation = true;
            this.backgroundWorker1.DoWork += new System.ComponentModel.DoWorkEventHandler(this.backgroundWorker1_DoWork);
            this.backgroundWorker1.ProgressChanged += new System.ComponentModel.ProgressChangedEventHandler(this.backgroundWorker1_ProgressChanged);
            this.backgroundWorker1.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.backgroundWorker1_RunWorkerCompleted);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1114, 503);
            this.pictureBox1.TabIndex = 5;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseDown);
            this.pictureBox1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseMove);
            this.pictureBox1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseUp);
            // 
            // ProgressBarFg
            // 
            this.ProgressBarFg.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.ProgressBarFg.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ProgressBarFg.BackgroundImage")));
            this.ProgressBarFg.Location = new System.Drawing.Point(150, 476);
            this.ProgressBarFg.Margin = new System.Windows.Forms.Padding(0);
            this.ProgressBarFg.Name = "ProgressBarFg";
            this.ProgressBarFg.Size = new System.Drawing.Size(657, 14);
            this.ProgressBarFg.TabIndex = 12;
            this.ProgressBarFg.TabStop = false;
            // 
            // statusLabel2
            // 
            this.statusLabel2.AutoSize = true;
            this.statusLabel2.BackColor = System.Drawing.Color.White;
            this.statusLabel2.Font = new System.Drawing.Font("Roboto Condensed", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.statusLabel2.ForeColor = System.Drawing.Color.White;
            this.statusLabel2.Location = new System.Drawing.Point(175, 445);
            this.statusLabel2.Name = "statusLabel2";
            this.statusLabel2.Size = new System.Drawing.Size(85, 18);
            this.statusLabel2.TabIndex = 17;
            this.statusLabel2.Text = "Files remaining";
            this.statusLabel2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // siteLabel
            // 
            this.siteLabel.AutoSize = true;
            this.siteLabel.BackColor = System.Drawing.Color.Transparent;
            this.siteLabel.Font = new System.Drawing.Font("Roboto Condensed", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.siteLabel.ForeColor = System.Drawing.Color.White;
            this.siteLabel.Location = new System.Drawing.Point(626, 445);
            this.siteLabel.Name = "siteLabel";
            this.siteLabel.Size = new System.Drawing.Size(115, 18);
            this.siteLabel.TabIndex = 16;
            this.siteLabel.Text = "Art by www.qx-cg.net";
            this.siteLabel.Click += new System.EventHandler(this.advancedLabel1_Click);
            // 
            // finalLabel
            // 
            this.finalLabel.AutoSize = true;
            this.finalLabel.BackColor = System.Drawing.Color.Transparent;
            this.finalLabel.Font = new System.Drawing.Font("Roboto Condensed", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.finalLabel.ForeColor = System.Drawing.Color.White;
            this.finalLabel.Location = new System.Drawing.Point(30, 409);
            this.finalLabel.Name = "finalLabel";
            this.finalLabel.Size = new System.Drawing.Size(122, 20);
            this.finalLabel.TabIndex = 15;
            this.finalLabel.Text = "Game is up-to-date!";
            this.finalLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // progressLabel
            // 
            this.progressLabel.AutoSize = true;
            this.progressLabel.BackColor = System.Drawing.Color.Transparent;
            this.progressLabel.Font = new System.Drawing.Font("Roboto Condensed", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.progressLabel.ForeColor = System.Drawing.Color.White;
            this.progressLabel.Location = new System.Drawing.Point(112, 472);
            this.progressLabel.Name = "progressLabel";
            this.progressLabel.Size = new System.Drawing.Size(35, 18);
            this.progressLabel.TabIndex = 14;
            this.progressLabel.Text = "100%";
            // 
            // advancedLabel3
            // 
            this.advancedLabel3.AutoSize = true;
            this.advancedLabel3.BackColor = System.Drawing.Color.Transparent;
            this.advancedLabel3.Font = new System.Drawing.Font("Roboto Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.advancedLabel3.ForeColor = System.Drawing.Color.White;
            this.advancedLabel3.Location = new System.Drawing.Point(30, 132);
            this.advancedLabel3.Name = "advancedLabel3";
            this.advancedLabel3.Size = new System.Drawing.Size(216, 21);
            this.advancedLabel3.TabIndex = 13;
            this.advancedLabel3.Text = "Welcome to Game Launcher Beta!";
            // 
            // advancedLabel2
            // 
            this.advancedLabel2.AutoSize = true;
            this.advancedLabel2.BackColor = System.Drawing.Color.Transparent;
            this.advancedLabel2.Font = new System.Drawing.Font("Roboto", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.advancedLabel2.ForeColor = System.Drawing.Color.White;
            this.advancedLabel2.Location = new System.Drawing.Point(31, 162);
            this.advancedLabel2.Name = "advancedLabel2";
            this.advancedLabel2.Size = new System.Drawing.Size(330, 90);
            this.advancedLabel2.TabIndex = 10;
            this.advancedLabel2.Text = resources.GetString("advancedLabel2.Text");
            // 
            // closeAdvBtn
            // 
            this.closeAdvBtn.ActiveImage = null;
            this.closeAdvBtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.closeAdvBtn.BackColor = System.Drawing.Color.Transparent;
            this.closeAdvBtn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("closeAdvBtn.BackgroundImage")));
            this.closeAdvBtn.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.closeAdvBtn.FlatAppearance.BorderSize = 0;
            this.closeAdvBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.closeAdvBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.closeAdvBtn.HoveredImage = null;
            this.closeAdvBtn.InactiveImage = null;
            this.closeAdvBtn.Location = new System.Drawing.Point(1086, 0);
            this.closeAdvBtn.Name = "closeAdvBtn";
            this.closeAdvBtn.PressedImage = null;
            this.closeAdvBtn.Size = new System.Drawing.Size(24, 24);
            this.closeAdvBtn.TabIndex = 9;
            this.closeAdvBtn.UseVisualStyleBackColor = false;
            this.closeAdvBtn.Click += new System.EventHandler(this.closeAdvBtn_Click);
            // 
            // minimizeAdvBtn
            // 
            this.minimizeAdvBtn.ActiveImage = global::Launcher01.Properties.Resources.ic_remove_white_24dp_1x;
            this.minimizeAdvBtn.BackColor = System.Drawing.Color.Transparent;
            this.minimizeAdvBtn.BackgroundImage = global::Launcher01.Properties.Resources.ic_remove_white_24dp_1x;
            this.minimizeAdvBtn.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.minimizeAdvBtn.FlatAppearance.BorderSize = 0;
            this.minimizeAdvBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.minimizeAdvBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.minimizeAdvBtn.HoveredImage = global::Launcher01.Properties.Resources.ic_remove_white_24dp_1x;
            this.minimizeAdvBtn.InactiveImage = global::Launcher01.Properties.Resources.ic_remove_white_24dp_1x;
            this.minimizeAdvBtn.Location = new System.Drawing.Point(1056, 0);
            this.minimizeAdvBtn.Name = "minimizeAdvBtn";
            this.minimizeAdvBtn.PressedImage = global::Launcher01.Properties.Resources.ic_remove_white_24dp_1x;
            this.minimizeAdvBtn.Size = new System.Drawing.Size(24, 24);
            this.minimizeAdvBtn.TabIndex = 8;
            this.minimizeAdvBtn.UseVisualStyleBackColor = false;
            this.minimizeAdvBtn.Click += new System.EventHandler(this.minimizeAdvBtn_Click);
            // 
            // statusLabel
            // 
            this.statusLabel.AutoSize = true;
            this.statusLabel.BackColor = System.Drawing.Color.White;
            this.statusLabel.Font = new System.Drawing.Font("Roboto Condensed", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.statusLabel.ForeColor = System.Drawing.Color.White;
            this.statusLabel.Location = new System.Drawing.Point(12, 445);
            this.statusLabel.Name = "statusLabel";
            this.statusLabel.Size = new System.Drawing.Size(114, 18);
            this.statusLabel.TabIndex = 7;
            this.statusLabel.Text = "Checking for updates";
            this.statusLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // PlayButton
            // 
            this.PlayButton.ActiveImage = ((System.Drawing.Image)(resources.GetObject("PlayButton.ActiveImage")));
            this.PlayButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.PlayButton.BackColor = System.Drawing.Color.Transparent;
            this.PlayButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("PlayButton.BackgroundImage")));
            this.PlayButton.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.PlayButton.FlatAppearance.BorderSize = 0;
            this.PlayButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.PlayButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.PlayButton.HoveredImage = ((System.Drawing.Image)(resources.GetObject("PlayButton.HoveredImage")));
            this.PlayButton.InactiveImage = null;
            this.PlayButton.Location = new System.Drawing.Point(953, 410);
            this.PlayButton.Margin = new System.Windows.Forms.Padding(0);
            this.PlayButton.Name = "PlayButton";
            this.PlayButton.PressedImage = ((System.Drawing.Image)(resources.GetObject("PlayButton.PressedImage")));
            this.PlayButton.Size = new System.Drawing.Size(114, 48);
            this.PlayButton.TabIndex = 6;
            this.PlayButton.UseVisualStyleBackColor = false;
            this.PlayButton.Click += new System.EventHandler(this.advancedButton1_Click);
            // 
            // Form1
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.DimGray;
            this.ClientSize = new System.Drawing.Size(1114, 503);
            this.Controls.Add(this.statusLabel2);
            this.Controls.Add(this.siteLabel);
            this.Controls.Add(this.finalLabel);
            this.Controls.Add(this.progressLabel);
            this.Controls.Add(this.advancedLabel3);
            this.Controls.Add(this.ProgressBarFg);
            this.Controls.Add(this.advancedLabel2);
            this.Controls.Add(this.closeAdvBtn);
            this.Controls.Add(this.minimizeAdvBtn);
            this.Controls.Add(this.statusLabel);
            this.Controls.Add(this.PlayButton);
            this.Controls.Add(this.pictureBox1);
            this.ForeColor = System.Drawing.Color.Black;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Launcher";
            this.TransparencyKey = System.Drawing.Color.DimGray;
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ProgressBarFg)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private AdvancedButton PlayButton;
        private AdvancedLabel statusLabel;
        private AdvancedButton minimizeAdvBtn;
        private AdvancedButton closeAdvBtn;
        private AdvancedLabel advancedLabel2;
        private AdvancedLabel advancedLabel3;
        private AdvancedLabel progressLabel;
        private AdvancedLabel finalLabel;
        private AdvancedLabel siteLabel;
        private AdvancedLabel statusLabel2;
        private System.Windows.Forms.PictureBox ProgressBarFg;
    }
}

