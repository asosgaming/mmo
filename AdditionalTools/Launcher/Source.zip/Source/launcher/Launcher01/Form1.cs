﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Diagnostics;
using System.Drawing.Text;

namespace Launcher01
{
    public partial class Form1 : Form
    {
        // used for dragging the main form
        private bool mouseDown;
        private Point originalMousePos;

        public static List<Button> buttonsToInitialize = new List<Button>();
        public static List<Label> labelsToInitialize = new List<Label>();

        public float progressPercentage = 0.1f;

        private BackgroundWorker worker;

        int totalProgressbarWidth;
        int currentProgress = 100;

        public Form1()
        {
            InitializeComponent();
        }

        // Executes when the program is launched and the form is loaded
        private void Form1_Load(object sender, EventArgs e)
        {
            SetStatus2("");

            // for main image transparency
            this.BackColor = Color.Lime;
            this.TransparencyKey = Color.Lime;

            // resets progress bar to 0
            InitializeProgressBar();

            PlayButton.Enabled = false;


            if (Program.ReadValuesFromIni())
            {
                Program.EmptyTempFolder();
                backgroundWorker1.RunWorkerAsync();
            }
            else
            {
                MessageBox.Show("LauncherSettings.ini wasn't found.", "Can't update",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            // works on their transparency
            foreach (Button btn in buttonsToInitialize)
                InitializeButton(btn);

            // works on their transparency
            foreach (Label lbl in labelsToInitialize)
                InitializeLabel(lbl);
        }

        //  1. Downloads xml file from the server
        //  2. Generates xml from local files if necessary
        //  3. Compares.
        //  4. Downloads required files.
        //  5. Unzips, overriding old files.
        //  6. Deletes downloaded zip files.
        //  7. Updates local xml file.

        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {
            worker = sender as BackgroundWorker;

            // downloads serverXml and ZipSize.xml
            Task downloadXml = Task.Run(()=> Program.GetServerXml());

            /* 
             * This block is executed in parallel as the xml file is being downloaded from the server.
             * We can use the spare time for anything else, such as generating localXml if we're trying to repair the game.
             */

            // loads or generates localXml
            Program.loadLocalXml();

            /*
             * end of block
             */

            // before proceeding, we wait for the xml to be downloaded fully
            downloadXml.Wait();

            // calculates the differences and fills the Program.filesToDownload list
            Program.CalculateDifferences();

            if (Program.filesToDownload.Count > 0)
            {
                // downloads files into a temp folder
                Program.DownloadRequiredFiles();

                // apply patch (unzip files from the Temp folder to root)
                Program.ApplyPatch();

                // Cleans up the .zip files, renames serverHash.xml to localHash.xml (deleting the original one)
                Program.FinalizePatch();
            }
            else
            {
                ;
                // delete serverHash.xml
            }

            SetProgress(100);
        }

        void InitializeButton(Button btn)
        {
            btn.Parent = pictureBox1;
        }

        void InitializeLabel(Label label)
        {
            var pos = this.PointToScreen(label.Location);
            pos = pictureBox1.PointToClient(pos);
            label.Parent = pictureBox1;
            label.Location = pos;
            label.BackColor = Color.Transparent;
        }

        protected override void OnPaintBackground(PaintEventArgs e)
        {
            e.Graphics.FillRectangle(Brushes.Lime, e.ClipRectangle);
        }

        // This event handler updates the progress.
        private void backgroundWorker1_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            SetProgressBar(e.ProgressPercentage);
        }

        // This method is called when backgroundWorker1_DoWork returns.
        private void backgroundWorker1_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            SetStatus("Game is up-to-date");

            // First, handle the case where an exception was thrown.
            if (e.Error != null)
            {
                //TODO display it in some other way than a messagebox
                MessageBox.Show(e.Error.Message);
            }
            else if (e.Cancelled)
            {
                // Next, handle the case where the user canceled the operation.
                // Note that due to a race condition in the DoWork event handler, the Cancelled
                // flag may not have been set, even though CancelAsync was called.

                // Be aware that your code in the DoWork event handler may finish its work as a cancellation 
                // request is being made, and your polling loop may miss CancellationPending being set to true. 
                // In this case, the Cancelled flag of System.ComponentModel.RunWorkerCompletedEventArgs in your 
                // RunWorkerCompleted event handler will not be set to true, even though a cancellation request 
                // was made. This situation is called a race condition and is a common concern in multithreaded 
                // programming. For more information about multithreading design issues, see Managed Threading 
                // Best Practices: https://msdn.microsoft.com/en-us/library/1c9txz50%28v=vs.110%29.aspx
                // Src: https://msdn.microsoft.com/en-us/library/system.componentmodel.backgroundworker.runworkercompleted%28v=vs.110%29.aspx

                // Let's try the job again.
                Console.WriteLine("Cancelled.");
                backgroundWorker1.RunWorkerAsync();
            }
            else
            {
                // Finally, handle the case where the operation succeeded.
                Console.WriteLine("Success.");

                // Enable the Play button.
                PlayButton.Enabled = true;
            }
        }

        private void ShowProgressBar(bool state)
        {            
            ProgressBarFg.Visible = state;
            progressLabel.Visible = state;
            statusLabel.Visible = state;
            statusLabel2.Visible = state;

            finalLabel.Visible = !state;
        }

        private void SetProgressBar(int value)
        {
            if (currentProgress != value)
            {
                // Invoke allows execution on the UI thread (instead of trying on the backgroundWorker thread)
                statusLabel.Invoke((MethodInvoker)delegate
                {
                    progressLabel.Text = value.ToString() + "%";

                    ProgressBarFg.Width = (totalProgressbarWidth * value) / 100;
                });

                currentProgress = value;
            }
        }

        private void InitializeProgressBar()
        {
            ShowProgressBar(true);

            totalProgressbarWidth = ProgressBarFg.Width;

            SetProgressBar(0);
        }

        // MouseDown, MouseMove and MouseUp allow dragging the main Form
        private void pictureBox1_MouseUp(object sender, MouseEventArgs e)
        {
            mouseDown = false;
        }

        // MouseDown, MouseMove and MouseUp allow dragging the main Form
        private void pictureBox1_MouseDown(object sender, MouseEventArgs e)
        {
            mouseDown = true;
            originalMousePos = e.Location;
        }

        // MouseDown, MouseMove and MouseUp allow dragging the main Form
        private void pictureBox1_MouseMove(object sender, MouseEventArgs e)
        {
            if (mouseDown) // && originalMousePos != e.Location
            {
                Point newLocation = new Point(this.Location.X + (e.X - originalMousePos.X), this.Location.Y + (e.Y - originalMousePos.Y));
                if (this.Location != newLocation)
                {
                    this.Location = newLocation;
                    // Update bodes better than Refresh and Invalidate, because it avoids flickering
                    this.Update();
                }
            }
        }

        public void SetStatus(string text)
        {
            if (text == "0") text = "almost done";

            // Invoke allows execution on the UI thread (instead of trying on the backgroundWorker thread)
            var someResult = statusLabel.Invoke((MethodInvoker)delegate
            {
                statusLabel.Text = text;
            });
        }

        public void SetStatus2(string text)
        {
            // Invoke allows execution on the UI thread (instead of trying on the backgroundWorker thread)
            statusLabel.Invoke((MethodInvoker)delegate
            {
                statusLabel2.Text = text;
            });
        }

        public void SetProgress(int percents)
        {
            worker.ReportProgress(percents);
        }

        private void closeAdvBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btn_close_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btn_minimize_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void minimizeAdvBtn_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void advancedButton1_Click(object sender, EventArgs e)
        {
            System.Media.SoundPlayer player = new System.Media.SoundPlayer();
                   
            player.Stream = Properties.Resources.play_click;
            player.Play(); //play "click" sound

            ProcessStartInfo start = new ProcessStartInfo();
            start.FileName = Program.exePath;
            Process.Start(start); //start the .exe
        }

        private void advancedLabel1_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("http://www.qx-cg.net/");
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}

